import logging
import os
import threading
import time
from bot import VideoMergeBot
from app import app  # Import the Flask app
from config import logger, TELEGRAM_TOKEN, TEMP_DOWNLOAD_DIR, TEMP_OUTPUT_DIR

# Ensure required directories exist
for directory in [TEMP_DOWNLOAD_DIR, TEMP_OUTPUT_DIR]:
    if not os.path.exists(directory):
        logger.info(f"Creating directory: {directory}")
        os.makedirs(directory, exist_ok=True)

# Start the bot in a separate thread
bot = None
if TELEGRAM_TOKEN:
    try:
        logger.info("Starting Video Merger Telegram Bot...")
        bot = VideoMergeBot()
        bot_thread = threading.Thread(target=bot.run)
        bot_thread.daemon = True
        bot_thread.start()
        logger.info("Bot initialized successfully")
    except Exception as e:
        logger.error(f"Error starting bot: {e}")
else:
    logger.warning("No TELEGRAM_TOKEN provided. Bot will not be started.")

# Make the app available for Gunicorn
# This is the variable that Gunicorn looks for
application = app

def main():
    """Main entry point for local development."""
    # Start the Flask app (for local development only)
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=True)

if __name__ == "__main__":
    main()
